/*********************************************************************
**
**   Visual Binary Diff
**   Copyright 1995-2017 by Christopher J. Madsen
**
**   Auto-generated version information
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program.  If not, see <https://www.gnu.org/licenses/>.
\*********************************************************************/
#ifndef PACKAGE_VERSION

#define PACKAGE_VERSION    "3.0_beta5"
#define PACKAGE_VERSION_NUM 3,0,200,5
#endif /* not PACKAGE_VERSION */
